<?php exit();?>
{
    "name": "wp_ecommerce.nety.ma_2023-04-06_12-08-45",
    "backup_dir": "1",
    "backup_db": "1",
    "email": "contact@ecommerce.nety.ma",
    "date_time": "2023-04-06 12:10:pm",
    "btime": 1680783000,
    "auto_backup": false,
    "ext": "tar.gz",
    "size": false,
    "backup_site_url": "https:\/\/ecommerce.nety.ma",
    "backup_site_path": "\/home\/netyma\/public_html\/ecommerce.nety.ma"
}